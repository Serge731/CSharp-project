using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BusManagement.Pages
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
