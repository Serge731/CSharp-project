﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace SHEILA_BSNS
{
    public partial class Land : Form
    {
        public Land()
        {
            InitializeComponent();
        }

        // Method to handle abtn button click (Save operation)
        private void abtn_Click(object sender, EventArgs e)
        {
            // Validate and get values from the updated textboxes
            string upi = utb.Text.Trim();  // UPI from utb TextBox
            if (!int.TryParse(stb.Text, out int size))  // Size from stb TextBox
            {
                MessageBox.Show("Please enter a valid size.");
                return;
            }
            string type = ttb.Text.Trim();  // Type from ttb TextBox
            string description = dtb.Text.Trim();  // Description from dtb TextBox
            if (!float.TryParse(ptb.Text, out float price))  // Price from ptb TextBox
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }

            // Connection string to your database
            string connectionString = @"Data Source=SQLEXPRESS;Initial Catalog=SHEILLA_DBS;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // SQL query to insert data into LAND table
                    string query = "INSERT INTO LAND (UPI, Size, Type, Description, Price) " +
                                   "VALUES (@UPI, @Size, @Type, @Description, @Price)";

                    // Create a command and assign the query and connection to it
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to prevent SQL injection
                        command.Parameters.AddWithValue("@UPI", upi);
                        command.Parameters.AddWithValue("@Size", size);
                        command.Parameters.AddWithValue("@Type", type);
                        command.Parameters.AddWithValue("@Description", description);
                        command.Parameters.AddWithValue("@Price", price);

                        // Open the connection
                        connection.Open();

                        // Execute the query
                        int rowsAffected = command.ExecuteNonQuery();

                        // Check if the data was inserted
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data saved successfully!");
                            ClearFields(); // Clear fields after successful save
                        }
                        else
                        {
                            MessageBox.Show("Failed to save data.");
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    // Handle SQL errors
                    MessageBox.Show("SQL Error: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    // Handle any other errors that occur during the insert operation
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // Method to clear input fields after saving
        private void ClearFields()
        {
            utb.Text = string.Empty;
            stb.Text = string.Empty;
            ttb.Text = string.Empty;
            dtb.Text = string.Empty;
            ptb.Text = string.Empty;
        }

        // Method to handle search operation (search button logic)
        private void searchbtn_Click(object sender, EventArgs e)
        {
            // Get the search query from the search TextBox
            string searchQuery = searchtb.Text.Trim();

            // Connection string to your database
            string connectionString = @"Data Source=vaillant\SQLEXPRESS;Initial Catalog=SHEILLA_DBS;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // SQL query to search the database using the UPI
                    string query = "SELECT * FROM LAND WHERE UPI = @SearchUPI";

                    // Create a command and assign the query and connection to it
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add the search parameter
                        command.Parameters.AddWithValue("@SearchUPI", searchQuery);

                        // Open the connection
                        connection.Open();

                        // Execute the query and get the results
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    // Display the fetched data in the corresponding textboxes
                                    utb.Text = reader["UPI"].ToString();
                                    stb.Text = reader["Size"].ToString();
                                    ttb.Text = reader["Type"].ToString();
                                    dtb.Text = reader["Description"].ToString();
                                    ptb.Text = reader["Price"].ToString();
                                }
                            }
                            else
                            {
                                MessageBox.Show("No record found.");
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    // Handle SQL errors
                    MessageBox.Show("SQL Error: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    // Handle any other errors that occur during the search operation
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}