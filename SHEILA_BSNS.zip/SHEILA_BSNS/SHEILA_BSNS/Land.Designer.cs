﻿namespace SHEILA_BSNS
{
    partial class Land
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.utb = new System.Windows.Forms.TextBox();
            this.etb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ptb = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtb = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.sbtn = new System.Windows.Forms.Button();
            this.searchtb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.abtn = new System.Windows.Forms.Button();
            this.ubtn = new System.Windows.Forms.Button();
            this.ttb = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // stb
            // 
            this.stb.Location = new System.Drawing.Point(42, 182);
            this.stb.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.stb.Name = "stb";
            this.stb.Size = new System.Drawing.Size(296, 20);
            this.stb.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 149);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "SIZE";
            // 
            // utb
            // 
            this.utb.Location = new System.Drawing.Point(42, 105);
            this.utb.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.utb.Name = "utb";
            this.utb.Size = new System.Drawing.Size(296, 20);
            this.utb.TabIndex = 9;
            // 
            // etb
            // 
            this.etb.AutoSize = true;
            this.etb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etb.Location = new System.Drawing.Point(39, 77);
            this.etb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.etb.Name = "etb";
            this.etb.Size = new System.Drawing.Size(32, 16);
            this.etb.TabIndex = 8;
            this.etb.Text = "UPI";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(83, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(451, 31);
            this.label1.TabIndex = 7;
            this.label1.Text = "WELCOME TO LAND MGT PAGE";
            // 
            // ptb
            // 
            this.ptb.Location = new System.Drawing.Point(42, 327);
            this.ptb.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ptb.Name = "ptb";
            this.ptb.Size = new System.Drawing.Size(296, 20);
            this.ptb.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 294);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "PRICE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(39, 222);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "TYPE";
            // 
            // dtb
            // 
            this.dtb.Location = new System.Drawing.Point(42, 398);
            this.dtb.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtb.Multiline = true;
            this.dtb.Name = "dtb";
            this.dtb.Size = new System.Drawing.Size(296, 51);
            this.dtb.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(39, 365);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 16);
            this.label5.TabIndex = 17;
            this.label5.Text = "DESCRIPTION";
            // 
            // sbtn
            // 
            this.sbtn.Location = new System.Drawing.Point(420, 149);
            this.sbtn.Name = "sbtn";
            this.sbtn.Size = new System.Drawing.Size(91, 31);
            this.sbtn.TabIndex = 19;
            this.sbtn.Text = "SEARCH";
            this.sbtn.UseVisualStyleBackColor = true;
            // 
            // searchtb
            // 
            this.searchtb.Location = new System.Drawing.Point(400, 123);
            this.searchtb.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.searchtb.Name = "searchtb";
            this.searchtb.Size = new System.Drawing.Size(220, 20);
            this.searchtb.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(407, 95);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 16);
            this.label6.TabIndex = 21;
            this.label6.Text = "ENTER SEARCH KEY";
            // 
            // abtn
            // 
            this.abtn.Location = new System.Drawing.Point(420, 215);
            this.abtn.Name = "abtn";
            this.abtn.Size = new System.Drawing.Size(91, 31);
            this.abtn.TabIndex = 22;
            this.abtn.Text = "ADD";
            this.abtn.UseVisualStyleBackColor = true;
            this.abtn.Click += new System.EventHandler(this.abtn_Click);
            // 
            // ubtn
            // 
            this.ubtn.Location = new System.Drawing.Point(420, 287);
            this.ubtn.Name = "ubtn";
            this.ubtn.Size = new System.Drawing.Size(91, 31);
            this.ubtn.TabIndex = 22;
            this.ubtn.Text = "UPDATE";
            this.ubtn.UseVisualStyleBackColor = true;
            // 
            // ttb
            // 
            this.ttb.FormattingEnabled = true;
            this.ttb.Items.AddRange(new object[] {
            "R1",
            "R2",
            "R3",
            "OTHERS"});
            this.ttb.Location = new System.Drawing.Point(42, 255);
            this.ttb.Name = "ttb";
            this.ttb.Size = new System.Drawing.Size(296, 21);
            this.ttb.TabIndex = 23;
            // 
            // Land
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 461);
            this.Controls.Add(this.ttb);
            this.Controls.Add(this.ubtn);
            this.Controls.Add(this.abtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.searchtb);
            this.Controls.Add(this.sbtn);
            this.Controls.Add(this.dtb);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ptb);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.stb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.utb);
            this.Controls.Add(this.etb);
            this.Controls.Add(this.label1);
            this.Name = "Land";
            this.Text = "land";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox stb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox utb;
        private System.Windows.Forms.Label etb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ptb;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dtb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button sbtn;
        private System.Windows.Forms.TextBox searchtb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button abtn;
        private System.Windows.Forms.Button ubtn;
        private System.Windows.Forms.ComboBox ttb;
    }
}